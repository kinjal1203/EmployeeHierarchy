package shah.kinjal;

import java.util.Comparator;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name="Employee")
public class Employee{
	
	private String name;
	private int id;
	private int salary;
	private String rating;
	private int managerId;
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getSalary() {
		return salary;
	}
	public void setSalary(int salary) {
		this.salary = salary;
	}
	public String getRating() {
		return rating;
	}
	public void setRating(String rating) {
		this.rating = rating;
	}
	public int getManagerId() {
		return managerId;
	}
	public void setManagerId(int managerId) {
		this.managerId = managerId;
	}
	
	public static final Comparator<Employee> SalaryComparator = new Comparator<Employee>(){

	@Override
	public int compare(Employee o1, Employee o2) {
		return (o1.getSalary() - o2.getSalary());
	}
	};


}
