package shah.kinjal;

import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

@Path("/employee")
@Consumes(MediaType.APPLICATION_XML)
@Produces(MediaType.APPLICATION_XML)
public class EmployeeServiceImpl implements EmployeeService {

	
	private static Map<Integer,Employee> employees = new HashMap<Integer,Employee>();

	@Override
	@POST
    @Path("/add")
	public Response addEmployee(Employee e) {
		Response response = new Response();
		if(employees.get(e.getId()) != null){
			response.setStatus(false);
			response.setMessage("Employee Already Exists");
			return response;
		}
		employees.put(e.getId(), e);
		response.setStatus(true);
		response.setMessage("Employee created successfully");
		return response;
	}
	

	@Override
	@GET
    @Path("/{id}/delete")
	public Response deleteEmployee(@PathParam("id") int id) {
		Response response = new Response();
		if(employees.get(id) == null){
			response.setStatus(false);
			response.setMessage("Employee Doesn't Exists");
			return response;
		}
		
		Employee employeeToDelete = employees.get(id);
		
		Map<Integer,Employee> reportees = new HashMap<Integer,Employee>();
		for(Employee e : employees){
			if(e.getManagerId() == employeeToDelete.getId()){
				reportees.put(e.getId(), e);
			}
		}
			int managerIdToSet = employeeToDelete.getManagerId();
			employees.remove(id);
			
			for(Employee e : reportees){
				
				e.setManagerId(managerIdToSet);
			}
			response.setStatus(true);
			response.setMessage("Employee deleted successfully");
		return response;
		
	}


	@Override
	@GET
	@Path("/getTopTen")
	public Employee[] getTopTenEmployee() {
		Collections.sort(employees, Employee.SalaryComparator);
		Employee[] e = new Employee[10];
		for(int i=0;i<10;i++){
			e[i] = employees.get(i);
		}
		return e;
	}


	@Override
	@GET
	@Path("/{id}/get")
	public void printHierarchy(@PathParam("id")int id) {

		int empid = id;
		while (employees.get(empid).getManagerId() !=0){
			System.out.println(employees.get(empid).getName() + ":" + employees.get(empid).getRating());
			empid = employees.get(empid).getManagerId();
		}
		
	}

}
