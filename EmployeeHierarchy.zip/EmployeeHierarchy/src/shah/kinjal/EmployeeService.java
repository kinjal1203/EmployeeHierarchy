package shah.kinjal;

public interface EmployeeService {
	
	public Response addEmployee(Employee e);
	
	public Response deleteEmployee(int id);
	
	public void printHierarchy(int id);
	
	public Employee[] getTopTenEmployee();

}
